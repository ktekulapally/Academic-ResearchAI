import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const AcademicResearchApp());

class AcademicResearchApp extends StatelessWidget {
  const AcademicResearchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Academic Research AI',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final question = TextEditingController();
  String status = 'Create a research question to begin.';
  String answer = '';
  int? projectId;
  int? questionId;
  int? runId;

  Future<void> startResearch() async {
    setState(() {
      status = 'Creating project...';
      answer = '';
    });

    final base = 'http://localhost:8000/api/v1';

    final p = await http.post(
      Uri.parse('$base/projects'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'name': question.text.length > 40
            ? '${question.text.substring(0, 40)}...'
            : question.text,
        'description': 'Student research workspace',
      }),
    );
    projectId = jsonDecode(p.body)['id'];

    final q = await http.post(
      Uri.parse('$base/projects/$projectId/questions'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'question': question.text}),
    );
    questionId = jsonDecode(q.body)['id'];

    final r = await http.post(Uri.parse('$base/questions/$questionId/research'));
    runId = jsonDecode(r.body)['id'];

    setState(() => status = 'Research run #$runId is running...');

    while (true) {
      await Future.delayed(const Duration(seconds: 4));
      final response = await http.get(Uri.parse('$base/research-runs/$runId'));
      final data = jsonDecode(response.body);

      if (data['status'] == 'completed') {
        setState(() {
          status = 'Research completed.';
          answer = data['answer'] ?? '';
        });
        break;
      }

      if (data['status'] == 'failed') {
        setState(() => status = 'Research failed: ${data['error']}');
        break;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Academic Research AI')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('What do you want to research?',
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 12),
                TextField(
                  controller: question,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Example: How is AI being used to improve crop disease detection?',
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: question.text.length >= 10 ? startResearch : null,
                  icon: const Icon(Icons.search),
                  label: const Text('Start Research'),
                ),
                const SizedBox(height: 16),
                Text(status),
                const SizedBox(height: 24),
                if (answer.isNotEmpty) ...[
                  Text('Research answer',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  Expanded(
                    child: SingleChildScrollView(child: SelectableText(answer)),
                  ),
                ] else
                  const Expanded(
                    child: Center(child: Text('Your evidence-backed result will appear here.')),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
