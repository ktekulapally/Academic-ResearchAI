from typing import TypedDict
from datetime import datetime
import hashlib
import re
import httpx
from langgraph.graph import StateGraph, START, END
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from .config import settings
from .db import SessionLocal
from .models import ResearchRun, ResearchQuestion, Source, Document, DocumentChunk, EvidenceItem, Claim
from .llm import chat_json, embed
from .search import search_openalex, search_crossref, search_searxng
from .documents import fetch_url, html_to_text, looks_like_pdf

COLLECTION = "research_chunks"

class ResearchState(TypedDict, total=False):
    run_id: int
    question_id: int
    question: str
    refined_question: str
    queries: list[str]
    sources: list[dict]
    evidence: list[dict]
    answer: str
    claims: list[dict]

def refine_question(s: ResearchState):
    data = chat_json(
        "You are an academic research assistant. Refine the student's question "
        "without changing its intent. Return JSON with keys refined_question and "
        "scope_notes. Keep it researchable and neutral.\nQUESTION:\n" + s["question"]
    )
    return {"refined_question": data.get("refined_question") or s["question"]}

def generate_queries(s: ResearchState):
    data = chat_json(
        "Generate 5 diverse academic search queries for the research question. "
        'Return JSON {"queries":["..."]}. Include conceptual, empirical, review, '
        "and domain-specific wording where appropriate.\nQUESTION:\n"
        + s["refined_question"]
    )
    return {"queries": [q.strip() for q in data.get("queries", []) if q.strip()][:5]}

def discover_sources(s: ResearchState):
    sources = []
    for q in s["queries"]:
        for fn in (search_openalex, search_crossref, search_searxng):
            try:
                sources.extend(fn(q, limit=5))
            except Exception:
                pass

    seen = set()
    unique = []
    for src in sources:
        url = src.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        title = (src.get("title") or "").lower()
        score = 0.0
        for term in re.findall(r"[a-z0-9]+", s["refined_question"].lower()):
            if len(term) > 3 and term in title:
                score += 1
        if src.get("doi"):
            score += 0.5
        if src.get("source_type") == "openalex":
            score += 1
        src["relevance_score"] = score
        unique.append(src)

    unique.sort(key=lambda x: x["relevance_score"], reverse=True)
    return {"sources": unique[:20]}

def acquire_evidence(s: ResearchState):
    db = SessionLocal()
    evidence = []
    qdrant = QdrantClient(url=settings.qdrant_url)

    for src in s.get("sources", [])[:12]:
        try:
            content_type, final_url, body = fetch_url(src["url"])
        except Exception:
            continue

        text = ""
        parser = "html"
        if looks_like_pdf(content_type, final_url):
            # GROBID is integrated in the architecture; PDF parsing is enabled
            # in the next worker milestone. Keep the source record even if the
            # remote PDF cannot be parsed in this API process.
            parser = "pdf-pending-grobid"
        else:
            text = html_to_text(body)[:50000]

        source = Source(
            run_id=s["run_id"],
            source_type=src["source_type"],
            title=src.get("title"),
            url=final_url,
            doi=src.get("doi"),
            authors=src.get("authors"),
            publication_year=src.get("publication_year"),
            relevance_score=src.get("relevance_score", 0),
            metadata=src.get("metadata"),
        )
        db.add(source)
        db.flush()

        if not text:
            continue

        document = Document(
            source_id=source.id,
            mime_type=content_type,
            extracted_text=text,
            parser=parser,
        )
        db.add(document)
        db.flush()

        chunks = [text[i:i+1800] for i in range(0, len(text), 1600)]
        for idx, chunk in enumerate(chunks[:30]):
            db_chunk = DocumentChunk(
                document_id=document.id,
                chunk_index=idx,
                text=chunk,
            )
            db.add(db_chunk)
            db.flush()

            try:
                vector = embed(chunk)
                point_id = hashlib.sha1(
                    f"{s['run_id']}:{document.id}:{idx}".encode()
                ).hexdigest()
                try:
                    qdrant.get_collection(COLLECTION)
                except Exception:
                    qdrant.create_collection(
                        collection_name=COLLECTION,
                        vectors_config=VectorParams(
                            size=len(vector), distance=Distance.COSINE
                        ),
                    )
                qdrant.upsert(
                    collection_name=COLLECTION,
                    points=[PointStruct(
                        id=point_id,
                        vector=vector,
                        payload={
                            "run_id": s["run_id"],
                            "document_id": document.id,
                            "chunk_id": db_chunk.id,
                            "text": chunk[:5000],
                        },
                    )],
                )
                db_chunk.qdrant_point_id = point_id
            except Exception:
                pass

            evidence.append({
                "source_id": source.id,
                "chunk_id": db_chunk.id,
                "text": chunk,
                "title": src.get("title"),
                "url": final_url,
            })

    db.commit()
    db.close()
    return {"evidence": evidence}

def synthesize(s: ResearchState):
    evidence_text = "\n\n".join(
        f"[EVIDENCE {i+1}] {e['title']}\n{e['text'][:5000]}\nURL: {e['url']}"
        for i, e in enumerate(s.get("evidence", [])[:12])
    )
    data = chat_json(
        "Answer the research question using ONLY the evidence supplied below. "
        "Return JSON with keys answer and claims. Each claim must contain claim, "
        "confidence, evidence_numbers. Do not invent citations or facts. If evidence "
        "is insufficient, say so.\nQUESTION:\n"
        + s["refined_question"] + "\nEVIDENCE:\n" + evidence_text
    )
    return {"answer": data.get("answer", ""), "claims": data.get("claims", [])}

def persist_result(s: ResearchState):
    db = SessionLocal()
    run = db.get(ResearchRun, s["run_id"])
    if not run:
        db.close()
        return {}

    for item in s.get("evidence", []):
        db.add(EvidenceItem(
            run_id=s["run_id"],
            source_id=item["source_id"],
            chunk_id=item["chunk_id"],
            quote=item["text"][:1000],
            locator=f"chunk:{item['chunk_id']}",
            relevance_score=1.0,
        ))

    evidence_rows = db.query(EvidenceItem).filter(EvidenceItem.run_id == s["run_id"]).all()
    for claim in s.get("claims", []):
        nums = claim.get("evidence_numbers") or []
        evidence_ids = []
        for n in nums:
            if isinstance(n, int) and 1 <= n <= len(evidence_rows):
                evidence_ids.append(evidence_rows[n-1].id)
        db.add(Claim(
            run_id=s["run_id"],
            claim=claim.get("claim", ""),
            confidence=float(claim.get("confidence", 0) or 0),
            evidence_ids=evidence_ids,
        ))

    run.answer = s.get("answer", "")
    run.status = "completed"
    run.source_count = len(s.get("sources", []))
    run.evidence_count = len(s.get("evidence", []))
    run.query_count = len(s.get("queries", []))
    run.completed_at = datetime.utcnow()
    db.commit()
    db.close()
    return {}

graph = StateGraph(ResearchState)
graph.add_node("refine_question", refine_question)
graph.add_node("generate_queries", generate_queries)
graph.add_node("discover_sources", discover_sources)
graph.add_node("acquire_evidence", acquire_evidence)
graph.add_node("synthesize", synthesize)
graph.add_node("persist_result", persist_result)
graph.add_edge(START, "refine_question")
graph.add_edge("refine_question", "generate_queries")
graph.add_edge("generate_queries", "discover_sources")
graph.add_edge("discover_sources", "acquire_evidence")
graph.add_edge("acquire_evidence", "synthesize")
graph.add_edge("synthesize", "persist_result")
graph.add_edge("persist_result", END)
RESEARCH_GRAPH = graph.compile()

def run_research(run_id: int, question_id: int, question: str):
    db = SessionLocal()
    run = db.get(ResearchRun, run_id)
    if run:
        run.status = "running"
        db.commit()
    db.close()

    try:
        RESEARCH_GRAPH.invoke({
            "run_id": run_id,
            "question_id": question_id,
            "question": question,
        })
    except Exception as exc:
        db = SessionLocal()
        run = db.get(ResearchRun, run_id)
        if run:
            run.status = "failed"
            run.error = str(exc)
            db.commit()
        db.close()
