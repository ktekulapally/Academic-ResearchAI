import json
import httpx
from .config import settings

def chat_json(prompt: str) -> dict:
    with httpx.Client(timeout=180) as client:
        response = client.post(
            f"{settings.ollama_base_url}/api/chat",
            json={
                "model": settings.ollama_chat_model,
                "stream": False,
                "format": "json",
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        response.raise_for_status()
        return json.loads(response.json()["message"]["content"])

def embed(text: str) -> list[float]:
    with httpx.Client(timeout=120) as client:
        response = client.post(
            f"{settings.ollama_base_url}/api/embed",
            json={"model": settings.ollama_embed_model, "input": text},
        )
        if response.status_code >= 400:
            response = client.post(
                f"{settings.ollama_base_url}/api/embeddings",
                json={"model": settings.ollama_embed_model, "prompt": text},
            )
        response.raise_for_status()
        data = response.json()
        if "embeddings" in data:
            return data["embeddings"][0]
        return data["embedding"]
