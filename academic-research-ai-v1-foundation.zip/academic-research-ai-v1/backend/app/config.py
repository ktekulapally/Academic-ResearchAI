import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./academic_research.db")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    qdrant_url: str = os.getenv("QDRANT_URL", "http://localhost:6333")
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    ollama_chat_model: str = os.getenv("OLLAMA_CHAT_MODEL", "qwen2.5:7b")
    ollama_embed_model: str = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
    searxng_url: str = os.getenv("SEARXNG_URL", "http://localhost:8080")
    openalex_url: str = os.getenv("OPENALEX_URL", "https://api.openalex.org")
    crossref_url: str = os.getenv("CROSSREF_URL", "https://api.crossref.org")
    grobid_url: str = os.getenv("GROBID_URL", "http://localhost:8070")
    minio_endpoint: str = os.getenv("MINIO_ENDPOINT", "localhost:9000")
    minio_access_key: str = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
    minio_secret_key: str = os.getenv("MINIO_SECRET_KEY", "minioadmin")
    minio_bucket: str = os.getenv("MINIO_BUCKET", "academic-documents")
    minio_secure: bool = os.getenv("MINIO_SECURE", "false").lower() == "true"

settings = Settings()
