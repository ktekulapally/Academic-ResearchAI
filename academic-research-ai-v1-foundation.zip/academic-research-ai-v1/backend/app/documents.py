import re
from pathlib import Path
from urllib.parse import urlparse
import httpx

def fetch_url(url: str) -> tuple[str, str, bytes]:
    with httpx.Client(timeout=60, follow_redirects=True) as client:
        r = client.get(url, headers={"User-Agent": "AcademicResearchAI/0.1"})
        r.raise_for_status()
        return r.headers.get("content-type", ""), str(r.url), r.content

def html_to_text(content: bytes) -> str:
    text = content.decode("utf-8", errors="ignore")
    text = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    return " ".join(text.split())

def looks_like_pdf(content_type: str, url: str) -> bool:
    return "application/pdf" in content_type.lower() or urlparse(url).path.lower().endswith(".pdf")
