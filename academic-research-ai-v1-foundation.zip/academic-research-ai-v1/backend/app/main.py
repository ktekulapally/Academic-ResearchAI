from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .db import init_db, SessionLocal
from .models import ResearchProject, ResearchQuestion, ResearchRun, Source, EvidenceItem
from .schemas import ProjectCreate, ProjectOut, QuestionCreate, QuestionOut, ResearchRunOut
from .research_graph import run_research

app = FastAPI(title="Academic Research AI", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok", "service": "academic-research-ai"}

@app.post("/api/v1/projects", response_model=ProjectOut)
def create_project(payload: ProjectCreate):
    db = SessionLocal()
    project = ResearchProject(name=payload.name, description=payload.description)
    db.add(project)
    db.commit()
    db.refresh(project)
    result = ProjectOut(id=project.id, name=project.name, description=project.description)
    db.close()
    return result

@app.get("/api/v1/projects")
def list_projects():
    db = SessionLocal()
    rows = db.query(ResearchProject).order_by(ResearchProject.id.desc()).all()
    result = [{"id": x.id, "name": x.name, "description": x.description} for x in rows]
    db.close()
    return result

@app.post("/api/v1/projects/{project_id}/questions", response_model=QuestionOut)
def create_question(project_id: int, payload: QuestionCreate):
    db = SessionLocal()
    if not db.get(ResearchProject, project_id):
        db.close()
        raise HTTPException(404, "Project not found")
    q = ResearchQuestion(project_id=project_id, question=payload.question)
    db.add(q)
    db.commit()
    db.refresh(q)
    result = QuestionOut(
        id=q.id, project_id=q.project_id,
        question=q.question, refined_question=q.refined_question
    )
    db.close()
    return result

@app.get("/api/v1/projects/{project_id}/questions")
def list_questions(project_id: int):
    db = SessionLocal()
    rows = db.query(ResearchQuestion).filter(
        ResearchQuestion.project_id == project_id
    ).order_by(ResearchQuestion.id.desc()).all()
    result = [
        {"id": x.id, "project_id": x.project_id, "question": x.question,
         "refined_question": x.refined_question}
        for x in rows
    ]
    db.close()
    return result

@app.post("/api/v1/questions/{question_id}/research", response_model=ResearchRunOut)
def start_research(question_id: int, background_tasks: BackgroundTasks):
    db = SessionLocal()
    question = db.get(ResearchQuestion, question_id)
    if not question:
        db.close()
        raise HTTPException(404, "Research question not found")
    run = ResearchRun(question_id=question_id, status="queued")
    db.add(run)
    db.commit()
    db.refresh(run)
    background_tasks.add_task(run_research, run.id, question.id, question.question)
    result = ResearchRunOut(
        id=run.id, question_id=run.question_id, status=run.status,
        query_count=0, source_count=0, evidence_count=0,
        answer=None, error=None
    )
    db.close()
    return result

@app.get("/api/v1/research-runs/{run_id}", response_model=ResearchRunOut)
def get_run(run_id: int):
    db = SessionLocal()
    run = db.get(ResearchRun, run_id)
    if not run:
        db.close()
        raise HTTPException(404, "Research run not found")
    result = ResearchRunOut(
        id=run.id, question_id=run.question_id, status=run.status,
        query_count=run.query_count, source_count=run.source_count,
        evidence_count=run.evidence_count, answer=run.answer, error=run.error
    )
    db.close()
    return result

@app.get("/api/v1/research-runs/{run_id}/sources")
def get_sources(run_id: int):
    db = SessionLocal()
    rows = db.query(Source).filter(Source.run_id == run_id).order_by(
        Source.relevance_score.desc()
    ).all()
    result = [{
        "id": x.id, "type": x.source_type, "title": x.title, "url": x.url,
        "doi": x.doi, "authors": x.authors, "publication_year": x.publication_year,
        "relevance_score": x.relevance_score
    } for x in rows]
    db.close()
    return result

@app.get("/api/v1/research-runs/{run_id}/evidence")
def get_evidence(run_id: int):
    db = SessionLocal()
    rows = db.query(EvidenceItem).filter(EvidenceItem.run_id == run_id).all()
    result = [{
        "id": x.id, "source_id": x.source_id, "chunk_id": x.chunk_id,
        "quote": x.quote, "locator": x.locator, "relevance_score": x.relevance_score
    } for x in rows]
    db.close()
    return result
